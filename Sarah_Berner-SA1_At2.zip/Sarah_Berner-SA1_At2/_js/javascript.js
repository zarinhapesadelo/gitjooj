function teste() {
    console.log(dados());


    if (verifica_cadastro()) {
        alert("Formulário correto!");
    } else {
        alert("Formulário com erro!");
    }

}

function verifica_cadastro() {
    var resultado = true;

    //Verifica o nome
    var nome = document.getElementById("name").value;
    if ((nome.length < 10) || (nome.length > 80)) {
        resultado = false;
    }

    //Verifica o apelido
    var apelido = document.getElementById("nickname").value;
    if ((apelido.length < 2) || (apelido.length > 20)) {
        resultado = false;
    }

    //Verifica dia
    var dia = parseInt(document.getElementById("day").value);
    if ((dia < 1) || (dia > 31) || (isNaN(dia))) {
        resultado = false;
    }

    //Verifica mês
    var mes = parseInt(document.getElementById("month").value);
    if ((mes < 1) || (mes > 12) || (isNaN(mes))) {
        resultado = false;
    }

    //Verifica ano
    var ano_atual = new Date().getFullYear();

    var ano = parseInt(document.getElementById("year").value);
    if ((ano < 1900) || (ano > ano_atual) || (isNaN(ano))) {
        resultado = false;
    }

    //Verifica CPF
    var expressao = /[0-9][0-9][0-9]\.[0-9][0-9][0-9]\.[0-9][0-9][0-9]\-[0-9][0-9]/;
    var cpf = document.getElementById("cpf").value;
    if (!(expressao.test(cpf))) {
        resultado = false;
    }

    //Verifica times
    var times = document.getElementsByTagName("option");
    var time_escolhido = 0;
    for (var i = 0; i < times.length; ++i) {
        if (times[i].selected) {
            time_escolhido = times[i].id;
        }
    }

    if ((time_escolhido == 0)) {
        resultado = false;
    }

    //Verifica esportes
    var esportes = document.getElementsByName("sport");
    var cont_esporte = 0;
    for (var i = 0; i < esportes.length; ++i) {
        if (esportes[i].checked) {
            cont_esporte = cont_esporte + 1;
        }
    }

    if ((cont_esporte == 0)) {
        resultado = false;
    }
    return resultado;
}

function dados() {
    var cadastro = new Object();

    cadastro.name = document.getElementById("name").value;

    cadastro.nickname = document.getElementById("nickname").value;

    cadastro.birth_date = document.getElementById("year").value + "-" +
        document.getElementById("month").value + "-" +
        document.getElementById("day").value;

    cadastro.cpf = document.getElementById("cpf").value;

    var times = document.getElementsByTagName("option");
    for (var i = 0; i < times.length; ++i) {
        if (times[i].selected) {
            cadastro.team_id = times[i].id;
        }
    }

    var esportes = document.getElementsByName("sport");
    cadastro.sport = [];
    for (var i = 0; i < esportes.length; ++i) {
        if (esportes[i].checked) {
            cadastro.sport.push(esportes[i].id);
        }
    }

    return cadastro;
}

function gerar_json() {

    var obj_form = {
        name: "",
        nickname: "",
        cpf: "",
        team_id: 0,
        sport: [],

    }

    var el_name = document.getElementById("name");
    if (el_name.value == "")
        return null;
    obj_form.name = el_name.value;

    var el_nickname = document.getElementById("nickname");
    obj_form.nickname = el_nickname.value;

    var el_cpf = document.getElementById("cpf");
    obj_form.cpf = el_cpf.value;

    var el_team = document.getElementById("team_id");
    obj_form.team_id = el_team.value;

    var el_sport_1 = document.getElementById("sport1");
    if (el_sport_1.checked == true)
        obj_form.sport.push(1);

    var el_sport_2 = document.getElementById("sport2");
    if (el_sport_2.checked == true)
        obj_form.sport.push(2);

    var el_sport_3 = document.getElementById("sport3");
    if (el_sport_3.checked == true)
        obj_form.sport.push(3);

    var el_sport_4 = document.getElementById("sport4");
    if (el_sport_4.checked == true)
        obj_form.sport.push(4);

    var el_sport_5 = document.getElementById("sport5");
    if (el_sport_5.checked == true)
        obj_form.sport.push(5);

    var el_sport_6 = document.getElementById("sport6");
    if (el_sport_6.checked == true)
        obj_form.sport.push(6);

    var el_sport_7 = document.getElementById("sport7");
    if (el_sport_7.checked == true)
        obj_form.sport.push(7);

    if (obj_form.sport.lenght == 0)
        return null;

    console.log(obj_form);

    var json = JSON.stringify(obj_form);
    console.log(json);
    document.write("<h1>Dados em Json</h1>");
    document.write(json);

    return json;
}